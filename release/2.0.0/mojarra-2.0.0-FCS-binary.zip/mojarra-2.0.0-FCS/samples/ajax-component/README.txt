This demo, the basic-ajax demo, is a collection of small example programs that have
been placed into a demo framework.

The best way to understand the demo is to simply run it - there are links in the
home page to each example, as well as the code backing each example.

The following examples are part of this demo:

switchlist in page - a simple example of two lists that communicate.  Building block for other demos
switchlist with ajax - converting switchlist in page to use ajax.
switchlist component - making switchlist in page into a component
switchlist ajax component - a full component that uses ajax.
editable text - display text which can be edited when clicked.
poll - a component which performs a periodic request to the server from the client
YUI Calendar - a JSF component which wraps a YUI Calendar widget
busy status - component which displays an image when an ajax request is active